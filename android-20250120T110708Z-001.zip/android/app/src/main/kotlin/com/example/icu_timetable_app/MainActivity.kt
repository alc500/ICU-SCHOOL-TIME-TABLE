package com.example.icu_timetable_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
